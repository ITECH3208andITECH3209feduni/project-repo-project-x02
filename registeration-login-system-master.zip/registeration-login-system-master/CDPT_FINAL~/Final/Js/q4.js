// creating an array and passing the number, questions, options, and answers
let q4 = [
    {
    numb: 1,
    question: "Which of the following instructs the computer hardware, what to do and how to do it?",
    answer: "Software",
    options: [
      "Hardware",
      "Operating System",
      "Device Driver",
      "Software"
    ]
  },
    {
    numb: 2,
    question: "A set of computer programs used on a computer to perform different tasks is called",
    answer: "Software",
    options: [
      "Software",
      "Hardware",
      "Processor",
      "None of the mentioned"
    ]
  },
    {
    numb: 3,
    question: "Which of the following is not a type of software?",
    answer: "Driver software",
    options: [
      "Utility software",
      "Driver software",
      " System software",
      " Application software"
    ]
  },
    {
    numb: 4,
    question: "Which software is used to manage and control the hardware components and allows interaction between the hardware and the other different types of software?",
    answer: "System software",
    options: [
      "System software",
      " Application software",
      "Utility software",
      "Operating system"
    ]
  },
    {
    numb: 5,
    question: " Which of the following is the part of system software?",
    answer: "both a and b",
    options: [
      "System software",
      " Application software",
      "Utility software",
      "both a and b"
    ]
  },
  {
    numb: 6,
    question: "The main function of computer software is to turn data into",
    answer: "information",
    options: [
      "information",
       "program",
       "object",
       "both a and c"
    ]
	
  },
  
  {
    numb: 7,
    question: "A computer program that functions as an intermediary between a computer user and the computer hardware is called",
    answer: "operating system",
    options: [
      " Software",
      " Hardware",
      "Driver",
      "operating system"
    ]
  },
  
  {
    numb: 8,
    question: "One or more defects occurring in the computer software that prevents the software from working is called",
    answer: "bug",
    options: [
      "bug",
      "system error",
      "bot",
      "slug"
    ]
  },
  {
    numb: 9,
    question: "Which of the following is a component of cyber security?",
    answer: "Internet Of Things",
    options: [
      " Attacks",
      "Database",
      "AI",
      "Internet Of Things"
    ]
  },
  
  {
    numb: 10,
    question: "Bug means",
    answer: " logical errors in the program",
    options: [
      "syntax error in the program",
      "runtime error",
      " logical errors in the program",
      "All of the above"
    ]
  },
]
  

  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
