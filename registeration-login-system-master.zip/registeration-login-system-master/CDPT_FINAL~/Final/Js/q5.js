// creating an array and passing the number, questions, options, and answers
let q5 = [
    {
    numb: 1,
    question: "Where was Gordon Ramsay born?",
    answer: "England",
    options: [
      "England",
      "America",
      "Scotland",
      "Wales"
    ]
  },
    {
    numb: 2,
    question: "A roux is often added while cooking to help thicken sauces or soups. What are the main ingredients of this sauces?",
    answer: "Flour and butter",
    options: [
      "Flour and oil",
      "Flour and egg",
      "Flour and water",
      "Flour and butter"
    ]
  },
    {
    numb: 3,
    question: "Which of the following kinds of pasta has its name meaning “little worms” in Italian?",
    answer: "Vermicelli",
    options: [
      "Spaghetti",
      "Fidelini",
      "Vermicelli",
      "Pesto"
    ]
  },
    {
    numb: 4,
    question: "Which of the following additives consists of skin and bones of animals?",
    answer: "Gelatin",
    options: [
      "Gelatin",
      "Custard powder",
      "Carrageenan",
      "Curry Powder"
    ]
  },
    {
    numb: 5,
    question: "What do we call the caramelised juices remaining in our pan after meat is browned?",
    answer: "Fond",
    options: [
      "Vignettes",
      "Fond",
      "Deglace",
      "lefton"
    ]
  },
  {
    numb: 6,
    question: "If you have 3/4 of a cup, how much more is needed to equal 1 cup?",
    answer: "1/4 cup",
    options: [
      "1/2 cup",
      "3/4 cup",
      "1/4 cup",
      "1/8 cup"
    ]
	
  },
  
  {
    numb: 7,
    question: "Identify the term that describes the amount of servings in a recipe.",
    answer: "portion",
    options: [
      " yield",
      "portion",
      "scale",
      "segment"
    ]
  },
  
  {
    numb: 8,
    question: "How many 1/4 cups are needed to equal 1 cup?",
    answer: "4",
    options: [
      "10",
      "6",
      "4",
      "2"
    ]
  },
  {
    numb: 9,
    question: "Why do we need to wash our hands before we eat or handle food?",
    answer: "Title tag",
    options: [
      "To prevent illness",
      "To avoid cross-contamination",
      "To keep our food germ-free",
      "All of the above"
    ]
  },
  
  {
    numb: 10,
    question: "What does Chef do?",
    answer: "Prepare the food",
    options: [
      "Prepare the food",
      "Eat",
      "Fight",
      "Cook"
    ]
  },

  

  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];