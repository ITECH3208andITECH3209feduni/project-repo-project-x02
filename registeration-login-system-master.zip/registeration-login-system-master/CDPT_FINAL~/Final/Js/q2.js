// creating an array and passing the number, questions, options, and answers
let q2 = [
    {
    numb: 1,
    question: "What is Cyber Security?",
    answer: "All of the mentioned",
    options: [
      "Cyber Security provides security against malware",
      "Cyber Security provides security against cyber-terrorists",
      "Cyber Security protects a system from cyber attacks",
      "All of the mentioned"
    ]
  },
    {
    numb: 2,
    question: "What does cyber security protect?",
    answer: "Cyber security protects criminals",
    options: [
      "Cyber security protects criminals",
      "Cyber security protects internet-connected systems",
      " Cyber security protects hackers",
      "None of the mentioned"
    ]
  },
    {
    numb: 3,
    question: "Who is the father of computer security?",
    answer: "August Kerckhoffs",
    options: [
      " Bob Thomas",
      "Robert",
      "Charles",
      " August Kerckhoffs"
    ]
  },
    {
    numb: 4,
    question: "Which of the following is defined as an attempt to steal, spy, damage or destroy computer systems, networks, or their associated information?",
    answer: "Cyber attack",
    options: [
      "Computer security",
      "Cryptography",
      "Cyber attack",
      "Digital hacking"
    ]
  },
    {
    numb: 5,
    question: "Which of the following is a type of cyber security?",
    answer: "All of the above",
    options: [
      "Cloud Security",
      " Network Security",
      "Application Security",
      "All of the above"
    ]
  },
  {
    numb: 6,
    question: "What are the features of cyber security?",
    answer: "All of the above",
    options: [
      "Compliance",
       "Defense against internal threats",
       "Threat Prevention",
       "All of the above"
    ]
	
  },
  
  {
    numb: 7,
    question: "Which of the following is an objective of network security?",
    answer: "All of the above",
    options: [
      " Availability",
      " Confidentiality",
      "Integrity",
      "All of the above"
    ]
  },
  
  {
    numb: 8,
    question: "Which of the following is not a cybercrime?",
    answer: "AES",
    options: [
      "Malware",
      "AES",
      "Man in the Middle",
      "Denial of Service"
    ]
  },
  {
    numb: 9,
    question: "Which of the following is a component of cyber security?",
    answer: "Internet Of Things",
    options: [
      " Attacks",
      "Database",
      "AI",
      "Internet Of Things"
    ]
  },
  
  {
    numb: 10,
    question: "Which of the following is a type of cyber attack?",
    answer: "All of the above",
    options: [
      "Phishing",
      "Password Attack",
      "SQL Injections",
      "All of the above"
    ]
  },
]
  

  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
