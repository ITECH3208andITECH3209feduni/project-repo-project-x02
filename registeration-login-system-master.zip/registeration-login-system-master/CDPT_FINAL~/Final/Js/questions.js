// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Which is used to introduce the medicated dusting Powder in to the body cavities",
    answer: " Insufflator",
    options: [
      "Suppositories",
      " Insufflator",
      "None of the Above",
      "Pessaries and stateless"
    ]
  },
    {
    numb: 2,
    question: "The Emulsions meant for external use should be which type",
    answer: "o/w",
    options: [
      "w/o",
      "o/w",
      "w/w",
      " o/o"
    ]
  },
    {
    numb: 3,
    question: "The Emulsions meant for internal use should be which type",
    answer: "w/o",
    options: [
      "w/o",
      "o/w",
      "w/w",
      " o/o"
    ]
  },
    {
    numb: 4,
    question: "The first edition of the pharmacopoeia of India was published in",
    answer: "1955",
    options: [
      "1947",
      "1966",
      "1955",
      "1952"
    ]
  },
    {
    numb: 5,
    question: "Which glass are used for storage of photosensitive pharmaceutical products",
    answer: "Amber colour",
    options: [
      "Blue colour",
      "Yellow Colour",
      "Amber colour",
      "None of the Above"
    ]
  },
  {
    numb: 6,
    question: "Particle size reduction increases the ..........of the solid substances",
    answer: "Surface area",
    options: [
      "Viscosity",
      "Crushing",
      "Absorption",
      "Surface area"
    ]
	
  },
  
  {
    numb: 7,
    question: "Ball mills work on the princeple of",
    answer: "Impact and Attrition",
    options: [
      " Crushing",
      "Attrition",
      "Impact",
      "Impact and Attrition"
    ]
  },
  
  {
    numb: 8,
    question: " Roller mills work on the princeple of",
    answer: "Compression and Attrition",
    options: [
      "Impact",
      "Attrition",
      "Compression",
      "Compression and Attrition"
    ]
  },
  {
    numb: 9,
    question: "What is used to separate the suspension of a solid in a gas",
    answer: "Cyclone separator",
    options: [
      "Cyclone separator",
      "Air separator",
      "Ball mill",
      "Roller mill"
    ]
  },
  
  {
    numb: 10,
    question: "Fine powder should pass through which sieve number",
    answer: "85",
    options: [
      "85",
      "65",
      "75",
      "1"
    ]
  },

  

  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];