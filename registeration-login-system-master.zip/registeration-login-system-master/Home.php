<?php
include("auth_session.php");
?>
<!DOCTYPE html>
<html class="no-js" prefix="og: https://ogp.me/ns#" lang="en-us" >
<head>
<script src="//code.tidio.co/oubgdcybmrhqm1jtyvuk0t0p0hf8zipa.js" async></script>
<link rel="preconnect" href="https://d1di2lzuh97fh2.cloudfront.net" crossorigin><meta charset="utf-8"><link rel="icon" type="image/png" href="https://img1.wsimg.com/isteam/ip/2aba169e-58e1-4fdf-a85b-c7c348dc1497/thumbnail.png/:/rs=w:50,h:49,cg:true,m/cr=w:50,h:49/qt=q:100/ll">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Home</title>
	<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
	<meta name="msapplication-tap-highlight" content="no">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://d1di2lzuh97fh2.cloudfront.net/files/4e/4eb/4ebtx8.css?ph=7f2222afc0" rel="stylesheet">
    <link href="https://d1di2lzuh97fh2.cloudfront.net/files/2k/2ki/2kinog.css?ph=7f2222afc0" media="screen and (min-width:37.5em)" rel="stylesheet" disabled>
    <link href="https://d1di2lzuh97fh2.cloudfront.net/files/0o/0o3/0o3vdr.css?ph=7f2222afc0" rel="stylesheet">
    <link href="https://d1di2lzuh97fh2.cloudfront.net/files/1f/1fw/1fw25g.css?ph=7f2222afc0" media="screen and (min-width:37.5em)" rel="stylesheet" disabled>
    <link href="https://d1di2lzuh97fh2.cloudfront.net/files/3r/3rv/3rvt8q.css?ph=7f2222afc0" media="print" rel="stylesheet">
	<link rel="stylesheet" href="https://d1di2lzuh97fh2.cloudfront.net/files/1z/1z8/1z8clx.css?ph=7f2222afc0" data-wnd_color_scheme_file=""><link rel="stylesheet" href="https://d1di2lzuh97fh2.cloudfront.net/files/10/10t/10twrm.css?ph=7f2222afc0" data-wnd_color_scheme_desktop_file="" media="screen and (min-width:37.5em)" disabled=""><link rel="stylesheet" href="https://d1di2lzuh97fh2.cloudfront.net/files/3k/3ky/3kylb1.css?ph=7f2222afc0" data-wnd_additive_color_file=""><link rel="stylesheet" href="https://d1di2lzuh97fh2.cloudfront.net/files/1z/1zh/1zhle5.css?ph=7f2222afc0" data-wnd_typography_file=""><link rel="stylesheet" href="https://d1di2lzuh97fh2.cloudfront.net/files/08/08d/08dooz.css?ph=7f2222afc0" data-wnd_typography_desktop_file="" media="screen and (min-width:37.5em)" disabled=""><script>function loadDesktopCSS(){if(!desktopStylesLoaded&&window.innerWidth>=600){for(var e=0,d=document.querySelectorAll('head > link[href*="css"][media="screen and (min-width:37.5em)"]');e<d.length;e++)d[e].removeAttribute("disabled");desktopStylesLoaded=!0}}var desktopStylesLoaded=!1;loadDesktopCSS(),window.addEventListener("resize",loadDesktopCSS)</script>
<link rel="preload stylesheet" href="https://d1di2lzuh97fh2.cloudfront.net/files/3u/3uv/3uvg6c.css?ph=7f2222afc0" as="style"><meta name="description" content="&quot;Alone we can do so little; together we can do so much.&quot;"><meta name="keywords" content=""><meta name="generator" content="Webnode 2"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black"><meta name="format-detection" content="telephone=no">
<body  class="l layout short-content wt-home ac-i ac-n l-default l-d-none b-btn-r b-btn-s-l b-btn-dbb b-btn-bw-2 img-d-r img-t-u img-h-o line-solid b-e-ds lbox-d c-s-s hn-tbg hb-on wnd-free-bar-fixed  wnd-fe">
	
	<div class="wnd-page l-page cs-gray ac-mint t-btn-fw-l t-nav-fw-l t-pd-fw-l">
		<div id="wrapper" class="l-w cf t-43">

			<div class="l-bg cf">
				<div class="s-bg-l">
                    
					
				</div>
				<div class="s-bg-l s-bg-lo"></div>
			</div>

			<header class="l-h cf">
				<div class="sw section-wrapper cf">
	<div class="sw-c section-wrapper-content cf"><section class="s s-hb cf sc-cd  sc-a wnd-w-default wnd-hbs-on">
	<div class="s-w cf">
		<div class="s-o cf">
			<div class="s-bg cf">
				<div class="s-bg-l">
                    
					
				</div>
				<div class="s-bg-l s-bg-lo"></div>
			</div>
			<div class="s-c">
                <div class="s-hb-c cf">
                    <div class="hb-si">
                        <div class="si">
    <div class="si-c"><!-- Place this tag where you want the booking button to show. -->
<div class="reservio-booking-button " data-business-id="employability-life" data-text="Book Appointment" data-bgcolor="#434343" data-color="#fff"></div>

<script id="reservio-widgets-script" type="text/javascript" src="https://static.reservio.com/js/widget.js">



</script>
<a style="font-size:20px" onclick="user()"><i class="fa fa-user"></i></a><a href="https://www.facebook.com/employabilitylife" target="_blank" rel="noreferrer nofollow" title="Facebook"><svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 24 24" height="18px" width="18px"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" fill="#bebebe"></path></svg></a><a href="https://www.instagram.com/employabilitylife" target="_blank" rel="noreferrer nofollow" title="Instagram"><svg viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg" height="18px" width="18px"><path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913a5.885 5.885 0 001.384 2.126A5.868 5.868 0 004.14 23.37c.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558a5.898 5.898 0 002.126-1.384 5.86 5.86 0 001.384-2.126c.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913a5.89 5.89 0 00-1.384-2.126A5.847 5.847 0 0019.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227a3.81 3.81 0 01-.899 1.382 3.744 3.744 0 01-1.38.896c-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421a3.716 3.716 0 01-1.379-.899 3.644 3.644 0 01-.9-1.38c-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678a6.162 6.162 0 100 12.324 6.162 6.162 0 100-12.324zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405a1.441 1.441 0 01-2.88 0 1.44 1.44 0 012.88 0z" fill="#bebebe"></path></svg></a><a href="https://www.linkedin.com/company/employability-life" target="_blank" rel="noreferrer nofollow" title="Linkedin"><svg viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg" height="18px" width="18px"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" fill="#bebebe"></path></svg></a><a href="https://www.twitter.com/Emplifenetwork" target="_blank" rel="noreferrer nofollow" title="Twitter"><svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 24 24" height="18px" width="18px"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" fill="#bebebe"></path></svg></a></div>
</div>
<script>
function user() {
	
   window.alert('<?php echo $_SESSION['username']; ?>');
   window.location.href='http://localhost/registeration-login-system-master/profile.php';
}
</script>          </div>
					
                    <div class="hb-ci">
                        
                    </div>
                    <div class="hb-ccy">
                        
                    </div>
                    <div class="hb-lang">
                        
                    </div>
                </div>
			</div>
		</div>
	</div>
</section><section class="s s-hn s-hn-default s-hn-bottom wnd-mt-classic wnd-na-c logo-classic sc-dt   wnd-w-default wnd-nh-m hn-no-bg  hm-claims  wnd-nav-sticky menu-bottom">
	<div class="s-w">
		<div class="s-o">

			<div class="s-bg">
				<div class="s-bg-l">
                    
					
				</div>
				<div class="s-bg-l s-bg-lo"></div>
			</div>

			<div class="h-w h-f wnd-fixed">

				<div class="n-l initial-state">
					<div class="s-c">
						<div class="logo-block">
							<div class="b b-l logo logo-default logo-nb fira-sans logo-25 wnd-logo-with-text wnd-iar-1-1 b-ls-m" id="wnd_LogoBlock_353782878" data-wnd_mvc_type="wnd.fe.LogoBlock">
	<div class="b-l-c logo-content">
		

			<div class="b-l-image logo-image">
				<div class="b-l-image-w logo-image-cell">
                    <picture><source type="image/webp" srcset="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000001-ed39ded39e/450/emp_logo.webp?ph=7f2222afc0 450w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000001-ed39ded39e/700/emp_logo.webp?ph=7f2222afc0 700w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000001-ed39ded39e/emp_logo.webp?ph=7f2222afc0 50w" sizes="(min-width: 600px) 450px, (min-width: 360px) calc(100vw * 0.8), 100vw" ><img src="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000000-249ac249ad/emp_logo.png?ph=7f2222afc0" alt="" width="50" height="49" class="wnd-logo-img" ></picture>
				</div>
			</div>

			

			<div class="b-l-br logo-br"></div>

			<div class="b-l-text logo-text-wrapper">
				<div class="b-l-text-w logo-text">
					<span class="b-l-text-c logo-text-cell">EMPLOYABILITY LIFE</span>
				
				
				
				</div>
			</div>

		
	</div>
</div>
						</div>
						<div class="cart-and-mobile">
							

                            

							<div id="menu-mobile">
								<a href="#" id="menu-submit"><span></span>Menu</a>
							</div>
						</div>

						<div id="menu-slider" >
							<div id="menu-block">
								<nav id="menu"  data-align="centered" class="centered" data-type="sliding" ><div class="menu-font menu-wrapper">
	<a href="#" class="menu-close" rel="nofollow" title="Close Menu"></a>
	<ul class="level-1">
		<li class="wnd-active   wnd-homepage">
			<a class="menu-item" href="Home.html"><span class="menu-item-text">Home</span></a>
			
		</li><li>
			<a class="menu-item" href="portals.html"><span class="menu-item-text">Portals</span></a>
			
		</li><li>
			<a class="menu-item" href="Project.html"><span class="menu-item-text">Our Project</span></a>
			
		</li><li>
			<a class="menu-item" href="About.html"><span class="menu-item-text">About Us</span></a>
			
		</li><li>
			<a class="menu-item" href="contact.html"><span class="menu-item-text">Contact</span></a>
			
		</li>
		<li>
			<a class="menu-item" href="FAQ.html"><span class="menu-item-text">FAQs</span></a>
		</li><li>
			<a class="menu-item" href="logout.php"><span class="menu-item-text">Sign Out</span></a>
			
		</li>
		<li>
		<style>
		.search1 {
			background-color: white; 
			color : red;
			
		}
		
		</style>
		

<!----This is the BEST search utility site------->
	

<script>
var enable_site_search = 1; // 0 = Don't enable; 1 = Enable site search along with page search
var find_window_fixed = 0; // 0 = User can move window with mouse; 1 = Window is fixed at top of screen // Version 5.4f
var find_window_background = "white"; // the color of the pop-up window
var find_window_border = "red"; // the border color of pop-up window
var find_text_color = "black"; // the color of the text in window
var find_title_color = "white"; // color of window title text
var find_window_width = 255; // width of window // Version 5.4h - From 245 to 255
//var find_window_height = 85; // height of window - Version 5.3f - No Longer Using
var find_root_node = null; // Leave as null to search entire doc or put id of div to search (ex: 'content'). Ver 5.0a - 7/18/2014
/* Do not edit the variables below this line */

// Simple drag object to hold all the variables for dragging
var drag = {mousex:0,mousey:0,tempx:'',tempy:'',isdrag:false, drag_obj:null, drag_obj_x:0, drag_obj_y:0};

var find_timer = 0;  // used for timer to move window in IE when scrolling

// Create highlights array to hold each new span element
var highlights = [];

// Which find are we currently highlighting
var find_pointer = -1;

var find_text = ''; // Global variable of searched for text

var found_highlight_rule = 0; // whether there is a highlight css rule
var found_selected_rule = 0; // whether there is a selected css rule

if (!find_window_fixed) { // Version 5.4f
document.onmousedown = MouseDown;
document.onmousemove = MouseMove;
document.onmouseup = MouseUp;

/*document.ontouchstart = MouseDown;
document.ontouchmove = MouseMove;
document.ontouchend = MouseUp;*/

document.addEventListener("touchstart", MouseDown, false); // Version 5.4g - Added just to match touchmove
document.addEventListener("touchmove", MouseMove, { passive: false }); // Version 5.4g - { passive: false } Needed to prevent iphone from scrolling screen on drag
document.addEventListener("touchend", MouseUp, false); // Version 5.4g - Added just to match touchmove

}


function highlight(word, node)
{
	if (!node)
		node = document.body;
	
	//var re = new RegExp(word, "i"); // regular expression of the search term // Ver 5.3c - Not using regular expressions search now
	
	for (node=node.firstChild; node; node=node.nextSibling)
	{	
		//console.log(node.nodeName);
		if (node.nodeType == 3) // text node
		{
			var n = node;
			//console.log(n.nodeValue);
			var match_pos = 0;
			//for (match_pos; match_pos > -1; n=after)
			{	
				//match_pos = n.nodeValue.search(re); // Ver 5.3b - Now NOT using regular expression because couldn't search for $ or ^
				match_pos = n.nodeValue.toLowerCase().indexOf(word.toLowerCase()); // Ver 5.3b - Using toLowerCase().indexOf instead
				
				if (match_pos > -1) // if we found a match
				{
					var before = n.nodeValue.substr(0, match_pos); // split into a part before the match
					var middle = n.nodeValue.substr(match_pos, word.length); // the matched word to preserve case
					//var after = n.splitText(match_pos+word.length);		
					var after = document.createTextNode(n.nodeValue.substr(match_pos+word.length)); // and the part after the match	
					var highlight_span = document.createElement("span"); // create a span in the middle
			        if (found_highlight_rule == 1)
						highlight_span.className = "highlight";
					else 
						highlight_span.style.backgroundColor = "yellow";	
			        
					highlight_span.appendChild(document.createTextNode(middle)); // insert word as textNode in new span
					n.nodeValue = before; // Turn node data into before
					n.parentNode.insertBefore(after, n.nextSibling); // insert after
		            n.parentNode.insertBefore(highlight_span, n.nextSibling); // insert new span
		           	highlights.push(highlight_span); // add new span to highlights array
		           	highlight_span.id = "highlight_span"+highlights.length;
					node=node.nextSibling; // Advance to next node or we get stuck in a loop because we created a span (child)
				}
			}
		}
		else // if not text node then it must be another element
		{
			// nodeType 1 = element
			if (node.nodeType == 1 && node.nodeName.match(/textarea|input/i) && node.type.match(/textarea|text|number|search|email|url|tel/i) && !getStyle(node, "display").match(/none/i)) 
				textarea2pre(node);
			else
			{
			if (node.nodeType == 1 && !getStyle(node, "visibility").match(/hidden/i)) // Dont search in hidden elements
			if (node.nodeType == 1 && !getStyle(node, "display").match(/none/i)) // Dont search in display:none elements
			highlight(word, node);
			}
		}
	}
	

} // end function highlight(word, node)


function unhighlight()
{
	for (var i = 0; i < highlights.length; i++)
	{
		
		var the_text_node = highlights[i].firstChild; // firstChild is the textnode in the highlighted span
	
		var parent_node = highlights[i].parentNode; // the parent element of the highlighted span
		
		// First replace each span with its text node nodeValue
		if (highlights[i].parentNode)
		{
			highlights[i].parentNode.replaceChild(the_text_node, highlights[i]);
			if (i == find_pointer) selectElementContents(the_text_node); // ver 5.1 - 10/17/2014 - select current find
			parent_node.normalize(); // The normalize() method removes empty Text nodes, and joins adjacent Text nodes in an element
			normalize(parent_node);	// Ver 5.2 - 3/10/2015 - normalize() is incorrect in IE. It will combine text nodes but may leave empty text nodes. So added normalize(node) function below		
		}
	}
	// Now reset highlights array
	highlights = [];
	find_pointer = -1; // ver 5.1 - 10/17/2014
} // end function unhighlight()


function normalize(node) {
//http://stackoverflow.com/questions/22337498/why-does-ie11-handle-node-normalize-incorrectly-for-the-minus-symbol
  if (!node) { return; }
  if (node.nodeType == 3) {
    while (node.nextSibling && node.nextSibling.nodeType == 3) {
      node.nodeValue += node.nextSibling.nodeValue;
      node.parentNode.removeChild(node.nextSibling);
    }
  } else {
    normalize(node.firstChild);
  }
  normalize(node.nextSibling);
}


function findit(dir) // Version 5.4f - Added dir
{
	// put the value of the textbox in string
	var string = document.getElementById('fwtext').value;
	dir = dir || 1; // 1 = next; 2 = prev
	
	// Version 5.4 - Site search
	if (enable_site_search && document.getElementById("find_site_search").checked) {
		var website = window.location.hostname; // Or replace with your website. Ex: example.com
		var url = "https://www.google.com/search?q=site%3A"+website+"+"+string;
		window.open(url, "coolfind");
		return;
	}
	
	// 8-9-2010 Turn DIV to hidden just while searching so doesn't find the text in the window
	findwindow.style.visibility = 'hidden';
	//findwindow.style.display = 'none';
		
	// if the text has not been changed and we have previous finds
	if (find_text.toLowerCase() == document.getElementById('fwtext').value.toLowerCase() &&
		find_pointer >= 0) 
	{	
		if (dir == 1) findnext(); // Find the next occurrence // Version 5.4f - Added if (dir == 1)
		else findprev(); // Version 5.4f - Added else findprev();
	}
	else
	{
		unhighlight(); // Remove highlights of any previous finds
		
		if (string == '') // if empty string
		{
			find_msg.innerHTML = "";
			findwindow.style.visibility = 'visible';
			return;
		}
		
		find_text = string;
		
		// Ver 5.0a - 7/18/2014. Next four lines because find_root_node won't exist until doc loads
		if (find_root_node != null)
			var node = document.getElementById(find_root_node);
		else
			var node = null;
		
		highlight(string, node); // highlight all occurrences of search string
		
		if (highlights.length > 0) // if we found occurences
		{
			find_pointer = -1;
			if (dir == 1) findnext(); // Find the next occurrence // Version 5.4f - Added if (dir == 1) 
			else findprev(); // Version 5.4f - Added else findprev();
		}
		else
		{
			find_msg.innerHTML = "0 of 0"; // ver 5.1 - 10/17/2014 - changed from "Not Found". Version 5.4h - Changed from &nbsp;<b>0 of 0</b> to 0 of 0
			find_pointer = -1;	
		}
	}
	findwindow.style.visibility = 'visible';
	//findwindow.style.display = 'block';	
	
}  // end function findit()


function findnext()
{
	var current_find;
	
	if (find_pointer != -1) // if not first find
	{
		current_find = highlights[find_pointer];
		
		// Turn current find back to yellow
		if (found_highlight_rule == 1)
			current_find.className = "highlight";
		else 
			current_find.style.backgroundColor = "yellow";
	}	
	
	find_pointer++;
	
	if (find_pointer >= highlights.length) // if we reached the end
			find_pointer = 0; // go back to first find
	
	var display_find = find_pointer+1;
	
	find_msg.innerHTML = display_find+" of "+highlights.length;
	
	current_find = highlights[find_pointer];
	
	// Turn selected find orange or add .find_selected css class to it
	if (found_selected_rule == 1)
			current_find.className = "find_selected";
		else 
			current_find.style.backgroundColor = "orange";
			
	//highlights[find_pointer].scrollIntoView(); // Scroll to selected element
	setTimeout(function(){ 
		scrollToPosition(highlights[find_pointer]);
	}, 250); // Version 5.4f - Android chrome was not scrolling to first find because keyboard taking too long to close?
} // end findnext()



// This function is to find backwards by pressing the Prev button
function findprev()
{
	var current_find;
	
	if (highlights.length < 1) return;
	
	if (find_pointer != -1) // if not first find
	{
		current_find = highlights[find_pointer];
		
		// Turn current find back to yellow
		if (found_highlight_rule == 1)
			current_find.className = "highlight";
		else 
			current_find.style.backgroundColor = "yellow";
	}	
	
	find_pointer--;
	
	if (find_pointer < 0) // if we reached the beginning
			find_pointer = highlights.length-1; // go back to last find
	
	var display_find = find_pointer+1;
	
	find_msg.innerHTML = display_find+" of "+highlights.length;
	
	current_find = highlights[find_pointer];
	
	// Turn selected find orange or add .find_selected css class to it
	if (found_selected_rule == 1)
			current_find.className = "find_selected";
		else 
			current_find.style.backgroundColor = "orange";
			
	//highlights[find_pointer].scrollIntoView(); // Scroll to selected element
	setTimeout(function(){ 
		scrollToPosition(highlights[find_pointer]);
	}, 250); // Version 5.4f - Android chrome was not scrolling to first find because keyboard taking too long to close?
	
} // end findprev()


// This function looks for the ENTER key (13) 
// while the find window is open, so that if the user
// presses ENTER it will do the find next
function checkkey(e)
{	
	var keycode;
	if (window.event)  // if ie
		keycode = window.event.keyCode;
	else // if Firefox or Netscape
		keycode = e.which;
	
	//find_msg.innerHTML = keycode;
	
	if (keycode == 13) // if ENTER key
	{	
		// ver 5.1 - 10/17/2014 - Blur on search so keyboard closes on iphone and android
		if (window.event && event.srcElement.id.match(/fwtext/i)) event.srcElement.blur(); 
		else if (e && e.target.id.match(/fwtext/i)) e.target.blur();
		findit(); // call findit() function (like pressing NEXT)	
	}
	else if (keycode == 27) // ESC key // Ver 5.1 - 10/17/2014
	{
		hide(); // Close find window on escape key pressed
	}
} // end function checkkey()


// This function makes the findwindow DIV visible
// so they can type in what they want to search for
function show()
{
	// Object to hold textbox so we can focus on it
	// so user can just start typing after "find" button
	// is clicked
	var textbox = document.getElementById('fwtext');
	
	// Make the find window visible
	findwindow.style.visibility = 'visible';
	//fwtext.style.visibility = 'visible';
	
	// Put cursor focus in the text box
	textbox.focus(); 
	textbox.select(); // ver 5.1 - 10/17/2014 - Select the text to search for
	textbox.setSelectionRange(0, 9999); // ver. 5.3 - 5/15/2015 - iOS woould not select without this
	// Call timer to move textbox in case they scroll the window
	if (!find_window_fixed) find_timer = setInterval('move_window();', 500); // Version 5.4f - Added if (!find_window_fixed) 
	// Setup to look for keypresses while window is open
	document.onkeydown = checkkey;
	
} // end function show()


// This function makes the findwindow DIV hidden
// for when they click on close
function hide()
{	
	unhighlight(); // Remove highlights of any previous finds - ver 5.1 - 10/17/2014
	findwindow.style.visibility = 'hidden';
	
	// turn off timer to move window on scrolling
	clearTimeout(find_timer);
	
	// Make document no longer look for enter key
	document.onkeydown = null;
	
} // end function hide()


// This function resets the txt selection pointer to the
// beginning of the body so that we can search from the
// beginning for the new search string when somebody
// enters new text in the find box
function resettext()
{
	if (find_text.toLowerCase() != document.getElementById('fwtext').value.toLowerCase())
		unhighlight(); // Remove highlights of any previous finds
	
} // end function resettext()


// This function makes the find window jump back into view
// if they scroll while it is open or if the page automatically
// scrolls when it is hightlighting the next found text
function move_window()
{
	//var findwindow = document.getElementById('findwindow');	
	
	// get current left, top and height of find_window
	var fwtop = parseFloat(findwindow.style.top);
	var fwleft = parseFloat(findwindow.style.left);
	// var fwheight = parseFloat(findwindow.style.height); // Version 5.3f - Was returning NaN in Chrome - changed to below
	var fwheight = parseFloat(findwindow.offsetHeight); // Version 5.3f 
	
	// get current top and bottom position of browser screen
	if (document.documentElement.scrollTop) // Needed if you use doctype loose.htm
		var current_top = document.documentElement.scrollTop;
	else 
		var current_top = document.body.scrollTop;
	
	// ver 2.3c 9/14/2013
	var current_bottom = (window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight) + current_top;
	
	// get current left and right position of browser
	if (document.documentElement.scrollLeft) // Needed if you use doctype loose.htm
		var current_left = document.documentElement.scrollLeft;
	else 
		var current_left = document.body.scrollLeft;
	
	// ver 2.3c 9/14/2013
	var current_right = (window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth) + current_left;

	
	//find_msg.innerHTML = current_right + ',' + current_left;
	
	// Only move window if it is out of the view
	if (fwtop < current_top)
	{	
		// move window to current_top
		findwindow.style.top = current_top + 30 +'px';	 
	}
	else if (fwtop > current_bottom - fwheight)
	{
		// move to current_bottom
		// findwindow.style.top = current_bottom - fwheight + 'px';	// Version 5.4h - Removed
		findwindow.style.top = current_top + 30 +'px'; // Version 5.4h - Added because iPhone does not support scrollIntoView behavior and block so it was covering finds at bottom
	}
	
	// Only move left position if out of view
	if (fwleft < current_left ||
		fwleft > current_right)
	{
		findwindow.style.left = current_left + 'px';
	}
	
	/* var find_msg = document.getElementById('find_msg');
	find_msg.innerHTML = 'find window: ' + fwtop
		+ ' curr_bottom: ' + current_bottom; */

} // end function move_window()


function MouseDown(event) 
{
	drag.tempx = drag.tempy = ''; // For single click on object
	if (!event) event = window.event; // 10/5/2014 - ver 5.0d - for older IE <= 9
	var fobj = event.target || event.srcElement; // The element being clicked on (FF || IE)

	// get current screen scrollTop and ScrollLeft 
	var scrollLeft = document.body.scrollLeft || document.documentElement.scrollLeft;
	var scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
  
	// ver 5.1 - 10/17/2014 - Let users highlight textareas and inputs by not dragging them 
	if (typeof fobj.nodeName != "undefined")
	if (fobj.nodeName.toLowerCase() == "input" ||
		fobj.nodeName.toLowerCase() == "textarea")
		return true;
	
	// If parent or grandparents of obj is a dragme item then make the parent the fobj
	for (fobj; fobj; fobj=fobj.parentNode)
	{
		// 7/30/2014 ver 5.0b
		if (fobj.className)
		if (String(fobj.className).match(/dragme/i))
			break;
	}
	
	// If parent of obj is a dragme item then make the parent the fobj
	/*if (fobj.parentNode.className)
	if (fobj.parentNode.className.match(/dragme/i))
		fobj = fobj.parentNode;*/
	if (fobj) // 7/30/2014 ver 5.0b
	if (fobj.className.match(/dragme/i)) // Only drag objects that have class="dragme"		
	{
		//fobj.style.zIndex = parseInt(getStyle(fobj, "z-index"))+1; // Make sure dragged object is in front
		// ^ ver 5.1 - 10/17/2014 - May have caused IE 8 Invalid Argument
		
		
		// If there was a previous object dragged then push it back on the screen
		//if (drag.drag_obj)
		//	drag.drag_obj.style.zIndex = parseInt(getStyle(fobj, "z-index"))-1;
		// ^ ver 5.1 - 10/17/2014 - May have caused IE 8 Invalid Argument	
		//if (document.getElementById('find_msg'))	 
		//	document.getElementById('find_msg').innerHTML = getStyle(fobj, "z-index");
		
		drag.isdrag = true; // Tell mouseMove we are dragging
		drag.drag_obj = fobj; // Put dragged element into global variable
		drag.drag_obj_x = parseInt(drag.drag_obj.offsetLeft); // get current x of element
		drag.drag_obj_y = parseInt(drag.drag_obj.offsetTop); // get current y of element
	
		// Add scrollTop and scrollLeft to recorded mouse position
		drag.mousex = event.clientX + scrollLeft;
		drag.mousey = event.clientY + scrollTop;
		
		/* if touchevents from iphone */
		if (event.type == "touchstart")
		if(event.touches.length == 1)
		{ // Only deal with one finger
		    var touch = event.touches[0]; // Get the information for finger #1
		    var node = touch.target; // Find the node the drag started from (redundant)
		    // node.style.position = "absolute";
		    drag.mousex = touch.pageX; // includes scroll offset
		    drag.mousey = touch.pageY; // includes scroll offset
		}
		return true; // 8/25/2014 version 5.0c (Now all buttons and onclick work on iphone and android)
	}
} // end function MouseDown(event) 


function MouseMove(event)
{
	if (drag.isdrag)
	{
		// Use 'event' above because IE only uses event and FF can use anything
		if (!event) event = window.event; // 10/5/2014 - ver 5.0d - for older IE <= 9
		drag.tempx = event.clientX; // record new mouse position x
		drag.tempy = event.clientY; // record new mouse position y
		
		// get current screen scrollTop and ScrollLeft 
		var scrollLeft = document.body.scrollLeft || document.documentElement.scrollLeft;
		var scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
		
	
	  	// Add scrollTop and scrollLeft to drag.tempx and drag.tempy
		drag.tempx += scrollLeft;
		drag.tempy += scrollTop;
		
		drag.drag_obj.style.position = 'absolute';
		
		/* if touchevents from iphone */
		if (event.type == "touchmove")
		if(event.touches.length == 1)
		{ // Only deal with one finger
		    var touch = event.touches[0]; // Get the information for finger #1
		    var node = touch.target; // Find the node the drag started from
		    // node.style.position = "absolute";
		    drag.tempx = touch.pageX; // includes scroll offset
		    drag.tempy = touch.pageY; // includes scroll offset
			// find_msg.innerHTML = event.type; // Version 5.4g - Test msg
			event.preventDefault(); // Version 5.4g - Stop iphone from scrolling page
			event.stopImmediatePropagation(); // Version 5.4g - Stop iphone from scrolling page
		}
	  	
		//if (document.getElementById('find_msg'))
		//	document.getElementById('find_msg').innerHTML = drag.tempx+", "+drag.tempy;
		// Dragged element position = old position + new mouse position - old mouse position
		
		drag.drag_obj.style.left = drag.drag_obj_x + drag.tempx - drag.mousex + "px"; // 7/30/2014 ver 5.0b
		drag.drag_obj.style.top  = drag.drag_obj_y + drag.tempy - drag.mousey + "px"; // 7/30/2014 ver 5.0b
		
		return false;
	}
} // end function MouseMove(event)



function MouseUp() 
{	
	if (drag.isdrag == true)
	{
		if (drag.tempx == '' && drag.tempy == '')
		{
			//if (document.getElementById('find_msg'))
			//	document.getElementById('find_msg').innerHTML += " You clicked!";
		}	
	}
	
	drag.isdrag = false;
	
}


function isOnScreen(el) // Version 5.4d
{
	/* This checks to see if an element is within the current user viewport or not */
	var scrollLeft = document.body.scrollLeft || document.documentElement.scrollLeft;
	var scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
	var screenHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight; // Version 1.2.0
	var screenWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth; // Version 1.2.0
	var scrollBottom = (window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight) + scrollTop;
	var scrollRight = (window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth) + scrollLeft;
	var onScreen = false;
	
	/* New way: el.getBoundingClientRect always returns 
		left, top, right, bottom of
		an element relative to the current screen viewport */ 
	var rect = el.getBoundingClientRect();
	if (rect.bottom >= 0 && rect.right >= 0 && 
		rect.top <= screenHeight && rect.left <= screenWidth) // Version 1.2.0 - Changed from scrollBottom and scrollRight
		return true;
	else { 
		// Verison 1.0.2 - Calculate how many pixels it is offscreen
		var distance = Math.min(Math.abs(rect.bottom), Math.abs(rect.right), Math.abs(rect.top - screenHeight), Math.abs(rect.left - screenWidth));	
		
		return -Math.abs(distance); // Version 1.0.2 - Return distance as a negative. Used to return false if off screen
	}
}


function scrollToPosition(field)
{  
   // This function scrolls to the DIV called 'edited'
   // It is called with onload.  'edited' only exists if
   // they just edited a comment or the last comment
   // if they just sent a comment
	var scrollLeft = document.body.scrollLeft || document.documentElement.scrollLeft;
	var scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
	var scrollBottom = (window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight) + scrollTop;
	var scrollRight = (window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth) + scrollLeft;

   if (field)
   {
		if (isOnScreen(field) != true) // Version 5.4d
		{
			//window.scrollTo(elemPosX ,elemPosY); 
			var isSmoothScrollSupported = 'scrollBehavior' in document.documentElement.style;
			if(isSmoothScrollSupported) {
	   			field.scrollIntoView({
			     behavior: "smooth",
			     block: "center"
			   });
			} else {
			   //fallback to prevent browser crashing
			   field.scrollIntoView(false);
			}
		}
		//window.scrollTo((field.getBoundingClientRect().left + scrollLeft) - ((scrollRight-scrollLeft)/2), (field.getBoundingClientRect().top + scrollTop) - ((scrollBottom-scrollTop)/2)); 
	}
}  // end function scrollToPosition()


/* It is not possible to get certain styles set in css such as display using 
the normal javascript.  So we have to use this function taken from:
http://www.quirksmode.org/dom/getstyles.html */
function getStyle(el,styleProp)
{
	// if el is a string of the id or the actual object of the element
	var x = (document.getElementById(el)) ? document.getElementById(el) : el;
	if (x.currentStyle) // IE
		var y = x.currentStyle[styleProp];
	else if (window.getComputedStyle)  // FF
		var y = document.defaultView.getComputedStyle(x,null).getPropertyValue(styleProp);
	return y;
}



// Create findwindow DIV but make it invisible
// It will be turned visible when user clicks on
// the "Find on this page..." button
function create_div(dleft, dtop, dwidth, dheight)
{
   	var info = "To add Cool JavaScript Find to your website go to: https://www.seabreezecomputers.com/tips/find.htm"; // Version 5.4e
	var position = (find_window_fixed) ? "fixed" : "absolute"; // Version 5.4f
	var cursor = (find_window_fixed) ? "default" : "move"; // Version 5.4h
	// This part creates a visible button on the HTML page to
	// where the script is pasted in the HTML code
	document.write('<input type="button" id="search1"  style="background-color: white; border: 1px red solid; margin-top: 10px; color: red;" class=”search1” value="Find in this page"'
	+ ' data-info="'+info+'"' // Version 5.4e - Added info // Version 5.4e - Moved out of global into create_div()
	+ ' onclick="show();">');
	
	if (document.documentElement.scrollTop) // Needed if you use doctype loose.htm
		var current_top = document.documentElement.scrollTop;
	else 
		var current_top = document.body.scrollTop;
	
    if (document.getElementById('findwindow'))
    {
        findwindow = document.getElementById('findwindow');
        //win_iframe = document.getElementById('win_iframe');
    }
    else
    { 
	    findwindow.id = "findwindow";
	    findwindow.style.position = position; // Version 5.4f
        //document.body.appendChild(findwindow);
        document.body.insertBefore(findwindow, document.body.firstChild);
        findwindow.className = 'findwindow dragme';
		findwindow.style.visibility = 'hidden';
		findwindow.setAttribute("data-info", info); // Version 5.4e
		// findwindow.style.touchAction = "none"; // Version 5.4g - Did not prevent page scrolling on iphone
	}
    
    findwindow.style.backgroundColor = find_window_background;
    findwindow.style.border = '2px solid ' + find_window_border;
    findwindow.style.color = find_text_color;
	findwindow.style.width = find_window_width + 'px';
	//findwindow.style.height = + find_window_height + 'px'; // Version 5.3f - No longer using
    findwindow.style.top = '20px';
	findwindow.style.left = '20px';
	findwindow.style.padding = '0px'; 
	findwindow.style.zIndex = 2147483647; // Version 5.4e
	findwindow.style.fontSize = '16px'; // Version 5.4h - Changed from 14px to 16px
	findwindow.style.overflowX = 'hidden';
	//findwindow.style.display = "block";
	
	// This part creates the title bar
	var string = '<div style="text-align: center'
	+ ';width: 100%' // Version 5.4e Was: // + ';width: ' + (find_window_width-20) + 'px'
	+ ';cursor: ' + cursor  // Version 5.4h - Turn mouse arrow to default or move icon 
	+ ';color: ' + find_title_color
	+ ';border: 1px solid ' + find_text_color
	+ ';background-color: ' + find_window_border
	//+ ';float: left' // Version 5.4e
	+ ';" onmouseover="over=1;" onmouseout="over=0;">'
	+ '<span style="font-size: small; background-color: red;">Powered by Muhammad Daniyal</span></div>'; // Version 5.4h - Added span with font-size: large
	// This part creates the closing X
	string += '<div onclick="hide();" class="close" style="text-align: center'
	+ ';width: ' + (20) + 'px' // Version5.4h - From 16 to 20
	+ ';cursor: pointer' // make mouse arrow stay an arrow instead of turning to text arrow // version 5.4h - From default to pointer
	+ ';font-weight: bold'
	+ ';background-color: blue'
	+ ';border: 0.5px solid ' + find_text_color
	+ ';position: absolute' // + ';float: right' // Version 5.4e 
	+ '; top: 1.6px; right: 2px ' // Version 5.4e
	+ '; font-size: small ' // Version 5.4h
	+ ';">'
	+ 'X' // write the letter X
	+ '</div>\n'; // Version 5.4h - Removed <br />
// This part creates the instructions and the "find" button
	string += '<div id="window_body" style="padding: 5px;" data-info="'+info+'">'
	+ '<form style="margin:0px;" onsubmit="return false;"><input type="search" size="25" maxlength="25" id="fwtext"' // Version 5.4h - Added form style="margin:0px;"
	+ ' style="width:100%; font-size:16px;"' // Version 5.4e - // Version 5.4g - Added font-size:16px to prevent iphone from zooming in on focus
	+ ' onchange="resettext();" placeholder="Enter text to find">'
	+ '<input type="button" value=" < " onclick="this.blur(); findit(2);" title="Find Previous">' // Ver 5.4f - Changed Find Next and Find Prev to just < and > - // Version 5.4f Changed findprev() to findit(0) // Version 5.4g - Added title attribute and this.blur()
	+ '<input type="button" value=" > " onclick="this.blur(); findit();" title="Find Next">' // ver 5.3 - 5/15/2015 - added this.blur(); // Version 5.4g - Added title attribute
	+ ' <span id="find_msg"> </span>'; // From <br /> to space
	if (enable_site_search) { // Version 5.4
		string += ' <label><input type="radio" name="search_type" value="page" checked>Page</label>'+ // Version 5.4h - Removed <br /> at beginning
		'<label><input type="radio" name="search_type" value="site" id="find_site_search">Site</label>';	
	}
	string += '</form></div>\n';
	// ^ ver 5.1 - 10/17/2014
	
	findwindow.innerHTML = string;
	
	// Check to see if css rules exist for highlight and find_selected.
	var sheets = document.styleSheets;
	for (var i=0; i < sheets.length; i++)
	{
		// IE <= 8 uses rules; FF & Chrome and IE 9+ users cssRules
		try { // Version 5.4c - Fix Firefox "InvalidAccessError: A parameter or an operation is not supported by the underlying object" bug
			var rules = (sheets[i].rules) ? sheets[i].rules : sheets[i].cssRules;
			if (rules != null)
			for (var j=0; j < rules.length; j++)
			{
				if (rules[j].selectorText == '.highlight')
					found_highlight_rule = 1;
				else if (rules[j].selectorText == '.find_selected')
					found_selected_rule = 1;
			}
		}
		catch(error) {
			console.error("Caught Firefox CSS loading error: "+error);
		}
	}
	
	
} // end function create_div()

function textarea2pre(el)
{		
	// el is the textarea element
	
	// If a pre has already been created for this textarea element then use it
	if (el.nextSibling && el.nextSibling.id && el.nextSibling.id.match(/pre_/i))
		var pre = el.nextsibling;
	else
		var pre = document.createElement("pre");
	
	var the_text = el.value; // All the text in the textarea		
	
	// replace <>" with entities
	the_text = the_text.replace(/>/g,'&gt;').replace(/</g,'&lt;').replace(/"/g,'&quot;');
	//var text_node = document.createTextNode(the_text); // create text node for pre with text in it
	//pre.appendChild(text_node); // add text_node to pre			
	pre.innerHTML = the_text;
	
	// Copy the complete HTML style from the textarea to the pre
	var completeStyle = "";
	if (typeof getComputedStyle !== 'undefined') // webkit
	{
		completeStyle = window.getComputedStyle(el, null).cssText;
		if (completeStyle != "") // Verison 5.3f - Is empty in IE 10 and Firefox
			pre.style.cssText = completeStyle; // Everything copies fine in Chrome
		else { // Version 5.3f - Because cssText is empty in IE 10 and Firefox
			var style = window.getComputedStyle(el, null);
			for (var i = 0; i < style.length; i++) {
    			completeStyle += style[i] + ": " + style.getPropertyValue(style[i]) + "; ";
    		}
    		pre.style.cssText = completeStyle;
		}
	}
	else if (el.currentStyle) // IE
	{
		var elStyle = el.currentStyle;
	    for (var k in elStyle) { completeStyle += k + ":" + elStyle[k] + ";"; }
	    //pre.style.cssText = completeStyle;
	    pre.style.border = "1px solid black"; // border not copying correctly in IE
	}
	
	el.parentNode.insertBefore(pre, el.nextSibling); // insert pre after textarea
	
	// If textarea blur then turn pre back on and textarea off
	el.onblur = function() { this.style.display = "none"; pre.style.display = "block"; };
	// If textarea changes then put new value back in pre
	el.onchange = function() { pre.innerHTML = el.value.replace(/>/g,'&gt;').replace(/</g,'&lt;').replace(/"/g,'&quot;'); };
	
	el.style.display = "none"; // hide textarea
	pre.id = "pre_"+highlights.length; // Add id to pre
	
	// Set onclick to turn pre off and turn textarea back on and perform a click on the textarea
	// for a possible onclick="this.select()" for the textarea
	pre.onclick = function() {this.style.display = "none"; el.style.display = "block"; el.focus(); el.click()};
	
	// this.parentNode.removeChild(this); // old remove pre in onclick function above
	 
} // end function textarea2pre(el)

// ver 5.1 - 10/17/2014
function selectElementContents(el) 
{
    /* http://stackoverflow.com/questions/8019534/how-can-i-use-javascript-to-select-text-in-a-pre-node-block */
	if (window.getSelection && document.createRange) {
        // IE 9 and non-IE
        var range = document.createRange();
        range.selectNodeContents(el);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
    } else if (document.body.createTextRange) {
        // IE < 9
        var textRange = document.body.createTextRange();
        textRange.moveToElementText(el);
        textRange.select();
        //textRange.execCommand("Copy");
    }
} // end function selectElementContents(el) 





	
// Create the DIV
var findwindow = document.createElement("div"); 
create_div();





var find_msg = document.getElementById('find_msg');

</script>


<!----Ends here--->

		
		
		</li>

	</ul>
	
	
</div></nav>
							</div>
						</div>

					</div>
				</div>

			</div>

		</div>
	</div>
</section></div>
</div>
			</header>

			<main class="l-m cf">
				<div class="sw section-wrapper cf">
	<div class="sw-c section-wrapper-content cf"><section class="s s-hm s-hm-claims cf sc-m wnd-background-image  wnd-w-default wnd-s-higher wnd-h-high wnd-nh-m wnd-p-cc hn-no-bg hn-default hn-bottom">
	<div class="s-w cf">
		<div class="s-o cf">
			<div class="s-bg">
				<div class="s-bg-l wnd-background-image fx-none bgatt-scroll bgpos-center-center">
                    <picture><source type="image/webp" srcset="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000005-6f1176f119/700/IMG-3400.webp?ph=7f2222afc0 700w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000005-6f1176f119/IMG-3400.webp?ph=7f2222afc0 1920w" sizes="100vw" ><img src="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000004-9fabd9fabe/IMG-3400.jpg?ph=7f2222afc0" width="1920" height="1440" alt="" ></picture>
					
				</div>
				<div class="s-bg-l s-bg-lo overlay-black-strong"></div>
			</div>
			<div class="h-c s-c">
				<div class="h-c-b">
					<div class="h-c-b-i">
						<h1>
							<div class="claim cf"><span class="sit b claim-default claim-nb alegreya claim-46">
	<span class="sit-w"><span class="sit-c"><strong>EMPLOYABILITY ASSESSMENT TOOLKIT</strong></span></span>
</span></div>
	                    </h1>
						<h3>
	                        <div class="claim cf"><span class="sit b claim-default claim-nb fira-sans claim-22">
	<span class="sit-w"><span class="sit-c">PREPARING LEARNERS FOR CAREER SUCCESS IN INDUSTRY!</span></span>
</span></div>
	                    </h3>
					</div>
				</div>
			</div>
		</div>
	</div>
</section><section class="s s-basic-box cf sc-ml wnd-background-pattern  wnd-w-default wnd-s-higher wnd-h-auto">
	<div class="s-w cf">
		<div class="s-o box-space cf">
			<div class="s-bg cf">
				<div class="s-bg-l wnd-background-pattern  bgpos-center-center bgatt-scroll" style="background-image:url('https://d1di2lzuh97fh2.cloudfront.net/files/02/02e/02ei6g.png?ph=7f2222afc0')">
                    
					
				</div>
				<div class="s-bg-l s-bg-lo"></div>
			</div>
			<div class="s-c sc-w cf">
				<div class="content ez cf wnd-no-cols">
	<div class="ez-c"><div class="b b-text cf">
	<div class="b-c b-text-c b-s b-s-t60 b-s-b60 b-cs cf"><h1 class="wnd-align-center">PROJECT TEAM MEMBERS</h1> <h3 class="wnd-align-center">"Alone we can do so little; together we can do so much."&nbsp;<br></h3> </div>
</div><div class="b b-s b-hr-line line-auto">
	<hr class="line-style line-color">
</div><div class="mt mt-image-top img-s-c img-s-c-small b-s-t50 b-s-b50 b-s-l0 b-s-r0 cf grid-4">
	<div class="mt-container">
		<div class="mt-item cf">
			<a href="https://www.linkedin.com/in/muhammad-daniyal-jahangir/" rel="nofollow" target="_blank">
				<div class="b-img b-img-default b b-s cf wnd-orientation-square wnd-type-image" style="" id="wnd_ImageBlock_479623291">
	<div class="b-img-w">
		<div class="b-img-c">
            <picture><source type="image/webp" srcset="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000009-c66fbc66fc/450/Muhammad_img.webp?ph=7f2222afc0 450w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000009-c66fbc66fc/700/Muhammad_img.webp?ph=7f2222afc0 700w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000009-c66fbc66fc/Muhammad_img.webp?ph=7f2222afc0 288w" sizes="(min-width: 768px) calc(100vw * 0.3), (min-width: 320px) calc(100vw * 0.5), 100vw" ><img id="wnd_ImageBlock_479623291_img" src="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000008-8ec808ec81/Muhammad_img.jpeg?ph=7f2222afc0" alt="" width="288" height="288" loading="lazy" style="" ></picture>
			<div class="b-img-embed">
				</div>
		</div>
		<div class="b-img-t"></div>
	</div>
</div>
				<div class="b b-text cf">
	<div class="b-c b-text-c b-s b-s-t60 b-s-b60 b-cs cf"><h3>Muhammad Daniyal</h3>

<h4><strong>Product</strong> <strong>Owner</strong>&nbsp;</h4><h4><span style="text-align: left;">Database Administrator<br></span><span style="text-align: left;">Web Developer</span></h4>
</div>
</div>
			</a>
		</div><div class="mt-item cf">
			<a href="https://www.linkedin.com/in/sukhtindervir-kaur-a17b431b5/" rel="nofollow" target="_blank">
				<div class="b-img b-img-default b b-s cf wnd-orientation-square wnd-type-image" style="" id="wnd_ImageBlock_804163169">
	<div class="b-img-w">
		<div class="b-img-c">
            <picture><source type="image/webp" srcset="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000011-55d2d55d2e/450/sukh_pic.webp?ph=7f2222afc0 450w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000011-55d2d55d2e/700/sukh_pic.webp?ph=7f2222afc0 700w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000011-55d2d55d2e/sukh_pic.webp?ph=7f2222afc0 800w" sizes="(min-width: 768px) calc(100vw * 0.3), (min-width: 320px) calc(100vw * 0.5), 100vw" ><img id="wnd_ImageBlock_804163169_img" src="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000010-1800218003/sukh_pic.jpg?ph=7f2222afc0" alt="" width="800" height="800" loading="lazy" style="" ></picture>
			<div class="b-img-embed">
				</div>
		</div>
		<div class="b-img-t"></div>
	</div>
</div>
				<div class="b b-text cf">
	<div class="b-c b-text-c b-s b-s-t60 b-s-b60 b-cs cf"><h3>Sukhtindervir Kaur</h3>

<h4><strong>Scrum Master</strong>&nbsp;</h4><h4>Tester</h4>
</div>
</div>
			</a>
		</div><div class="mt-item cf">
			
				<div class="b-img b-img-default b b-s cf wnd-orientation-portrait wnd-type-image" style="" id="wnd_ImageBlock_960089444">
	<div class="b-img-w">
		<div class="b-img-c">
            <picture><source type="image/webp" srcset="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000013-bdf81bdf82/450/suraj_img.webp?ph=7f2222afc0 450w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000013-bdf81bdf82/700/suraj_img.webp?ph=7f2222afc0 700w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000013-bdf81bdf82/suraj_img.webp?ph=7f2222afc0 768w" sizes="(min-width: 768px) calc(100vw * 0.3), (min-width: 320px) calc(100vw * 0.5), 100vw" ><img id="wnd_ImageBlock_960089444_img" src="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000012-4c8604c862/suraj_img.jpg?ph=7f2222afc0" alt="" width="768" height="1024" loading="lazy" style="" ></picture>
			<div class="b-img-embed">
				</div>
		</div>
		<div class="b-img-t"></div>
	</div>
</div>
				<div class="b b-text cf">
	<div class="b-c b-text-c b-s b-s-t60 b-s-b60 b-cs cf"><h3>Suraj Mahat</h3>

<h4><strong>Team Member</strong></h4><h4>Application Developer</h4>
</div>
</div>
			
		</div><div class="mt-item cf">
			
				<div class="b-img b-img-default b b-s cf wnd-orientation-landscape wnd-type-image" style="" id="wnd_ImageBlock_671803639">
	<div class="b-img-w">
		<div class="b-img-c">
            <picture><source type="image/webp" srcset="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000017-6407b6407c/450/PHOTO-2022-08-12-12-39-08-7.webp?ph=7f2222afc0 450w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000017-6407b6407c/700/PHOTO-2022-08-12-12-39-08-7.webp?ph=7f2222afc0 700w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000017-6407b6407c/PHOTO-2022-08-12-12-39-08-7.webp?ph=7f2222afc0 334w" sizes="(min-width: 768px) calc(100vw * 0.3), (min-width: 320px) calc(100vw * 0.5), 100vw" ><img id="wnd_ImageBlock_671803639_img" src="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000016-4daf74daf9/PHOTO-2022-08-12-12-39-08.jpg?ph=7f2222afc0" alt="" width="334" height="248" loading="lazy" style="" ></picture>
			<div class="b-img-embed">
				</div>
		</div>
		<div class="b-img-t"></div>
	</div>
</div>
				<div class="b b-text cf">
	<div class="b-c b-text-c b-s b-s-t60 b-s-b60 b-cs cf"><h3>Pratik Lammichanne&nbsp;</h3><h4><strong>Team Member</strong></h4>

<h4>Application Developer</h4>
</div>
</div>
			
		</div><div class="mt-item cf">
			
				<div class="b-img b-img-default b b-s cf wnd-orientation-landscape wnd-type-image" style="" id="wnd_ImageBlock_382981999">
	<div class="b-img-w">
		<div class="b-img-c">
            <picture><source type="image/webp" srcset="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000019-f1dfbf1dfd/450/roshan_img.webp?ph=7f2222afc0 450w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000019-f1dfbf1dfd/700/roshan_img.webp?ph=7f2222afc0 700w, https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000019-f1dfbf1dfd/roshan_img.webp?ph=7f2222afc0 217w" sizes="(min-width: 768px) calc(100vw * 0.3), (min-width: 320px) calc(100vw * 0.5), 100vw" ><img id="wnd_ImageBlock_382981999_img" src="https://7f2222afc0.cbaul-cdnwnd.com/6d3295ccdd45c3a974feaab357d100d5/200000018-1d0a21d0a3/roshan_img.jpg?ph=7f2222afc0" alt="" width="217" height="194" loading="lazy" style="" ></picture>
			<div class="b-img-embed">
				</div>
		</div>
		<div class="b-img-t"></div>
	</div>
</div>
				<div class="b b-text cf">
	<div class="b-c b-text-c b-s b-s-t60 b-s-b60 b-cs cf"><h3>Roshan Shrestha</h3>

<h4><strong>Team Member</strong></h4><h4>Application Developer</h4>
</div>
</div>
			
		</div>
	</div>
</div><div class="b b-s b-hr-line line-auto">
	<hr class="line-style line-color">
</div><div class="b b-s b-s-t150 b-s-b150 b-btn b-btn-1 wnd-align-center">
	<div class="b-btn-c i-a">
		<a class="b-btn-l" href="About.html">
			<span class="b-btn-t">Our Project</span>
		</a>
	</div>
</div></div>
</div>
			</div>
		</div>
	</div>
</section><section class="s s-hc s-hc-cta-claim cf sc-m wnd-background-image  wnd-w-default wnd-s-higher wnd-hh-auto wnd-p-cc">
	<div class="s-w cf">
		<div class="s-o cf">
			<div class="s-bg cf">
				<div class="s-bg-l wnd-background-image fx-none bgpos-center-center bgatt-scroll">
                    <picture><img src="https://d1di2lzuh97fh2.cloudfront.net/files/0s/0su/0su4tq.jpg?ph=7f2222afc0" width="1920" height="1279" alt="" loading="lazy" ></picture>
					
				</div>
				<div class="s-bg-l s-bg-lo overlay-black"></div>
			</div>
			<div class="s-c cf">
				<div class="s-hc-c">
					<h2 class="s-hc-claim claim i-a"><span class="sit b claim-default claim-nb fira-sans claim-58">
	<span class="sit-w"><span class="sit-c">Start your journey to success!</span></span>
</span></h2>
					<div class="b b-s b-s-t150 b-s-b150 b-btn b-btn-2">
	<div class="b-btn-c i-a">
		<a class="b-btn-l" href="contact.html">
			<span class="b-btn-t">Contact Us</span>
		</a>
	</div>
</div>
				</div>
			</div>
		</div>
	</div>
</section></div>
</div>
			</main>

			<footer class="l-f cf">
				<div class="sw section-wrapper cf">
	<div class="sw-c section-wrapper-content cf"><section data-wn-border-element="s-f-border" class="s s-f s-f-edit sc-d   wnd-w-default wnd-s-higher wnd-h-auto">
	<div class="s-w">
		<div class="s-o">
			<div class="s-bg">
				<div class="s-bg-l">
                    
					
				</div>
				<div class="s-bg-l s-bg-lo"></div>
			</div>
			<div class="s-f-ez">
				<div class="s-c s-f-border">
					<div>
						<div class="content ez cf">
	<div class="ez-c"><div class="column-wrapper cw cf">
	<div class="cw-c cf"><div class="column-content c cf pr" style="width:50%;">
	<div class="c-c cf"><div class="b b-text cf">
	<div class="b-c b-text-c b-s b-s-t60 b-s-b60 b-cs cf"><h2><strong>Get in touch</strong></h2>

<p><strong>Visit us</strong><br>9/540 George St, Town Hall, Sydney, NSW, 2000</p>

<p><strong>Give us a call</strong><br>
(541)&nbsp;754-3010</p>

<p><strong>Email</strong><br>enquire@atmc.edu.au</p>
</div>
</div></div>
</div><div class="column-content c cf pr" style="width:50%;">
	<div class="c-c cf"><div class="b b-text cf">
	<div class="b-c b-text-c b-s b-s-t60 b-s-b60 b-cs cf"><h2><strong>Enquire Now!</strong></h2>

<h3>Prepare for a Successful Career in Industry 4.0</h3>
</div>
</div><div class="form b b-s b-form-default f-rh-normal f-rg-normal f-br-none default cf">
	 <form action="https://formsubmit.co/mdaniyalmuz@gmail.com" enctype="multipart/form-data" method="POST" >
    	<input type="hidden" name="_template" value="table">
	<input type="hidden" name="_next" value="http://localhost/registeration-login-system-master/thanks.html">
    <input type="hidden" name="_captcha" value="false">  
   

		<fieldset class="form-fieldset">
			<div><div class="form-input form-email cf wnd-form-field wnd-required">
	<label for="field-wnd_EmailField_942930796"><span class="it b inline-text link">
	<span class="it-c">Email</span>
</span></label>
	<input id="field-wnd_EmailField_942930796" name="User Email ID" required type="email" maxlength="255">
</div></div>
		</fieldset>

		

		<div class="form-submit b-btn cf b-btn-fs b-btn-3">
			<button class="b-btn-l" type="submit" name="send" value="Response Requested">
				<span class="form-submit-text b-btn-t">Send</span>
			</button>
		</div>

	</form>

	
</div></div>
</div></div>
</div></div>
</div>
					</div>
				</div>
			</div>
			<div class="s-c s-f-l-w" >
				<div class="s-f-l b-s b-s-t0 b-s-b0">
					<div class="s-f-l-c s-f-l-c-first">
						<div class="s-f-sf">
							<span class="sf b">
<span class="sf-content sf-c link">Powered by <a href="http://localhost/registeration-login-system-master/Project.html" target="_blank"><strong>Project X02</strong></a></span>

</span>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</div>
	<div class="s-f-bg-stripe"></div>
</section></div>
</div>
			</footer>
		</div>


	
<script>!function(){if(0==document.getElementsByClassName("wnd-cms").length)for(var e=document.getElementsByClassName("column-content"),s=0;s<e.length;s++){var t=e[s].querySelector("div"),l=t.getElementsByClassName("b-text-c");void 0!=l[0]&&t.firstChild==t.lastChild&&""===l[0].innerText&&(e[s].classList?e[s].classList.add("column-empty"):(e[s].classList?e[s].classList.contains("column-empty"):new RegExp("\\bcolumn-empty\\b").test(e[s].className))&&(e[s].className+=" column-empty"))}}()</script>
	<script type="module" src="https://d1di2lzuh97fh2.cloudfront.net/files/1b/1bb/1bb767.js?ph=7f2222afc0"></script>





	
 <style>
      .disabled {
        user-select: none;
        -webkit-user-select: none;
        -moz-user-select: none;
      }
	  
     
    </style>	



<div class="bg-black-025 bs-sm bt bc-black-100 ps-fixed l0 r0 b0 z-nav js-dismissable-hero" id="myDIV" style="height: 50px;">
    <div class="d-flex wmx12 mx-auto px8 py12 jc-space-between ai-center lg:pl24 lg:pr24 md:fd-column sm:fd-row sm:ai-center">
        <div class="flex--item fs-body2 fl1 mr16 md:mr0 md:mb12 sm:mb0 sm:mr16" style="margin-left:20px;">
            <p class="mb0"><strong>Welcome</strong> to Employability Assessment Toolkit.</p>
        </div>

        <button id="openid-buttons" onclick="displayIframe()" class="d-flex gs8 gsx ai-center sm:jc-space-between" style="padding: 5px; background-color: #e1ecf4; border: 1px black solid; margin-right: 20px;">
            <a >
                    <span class="sm:d-none" ><strong > <a href="https://github.com/ITECH3208andITECH3209feduni/project-repo-project-x02/raw/master/Terms%20and%20conditions%20-%20Employability%20Assessment%20Toolkit.pdf" target="_blank" style="text-decoration: none;"> View website Terms and Conditions</strong></a></span>

                
            </a>

                  </button>
				   <div id="openid-buttons" class="d-flex gs8 gsx ai-center sm:jc-space-between" style="padding: 5px; background-color: #e1ecf4; border: 1px black solid; margin-right: 20px;">
            <a >
                    <span class="sm:d-none" ><strong > <a href="https://github.com/ITECH3208andITECH3209feduni/project-repo-project-x02/raw/master/Privacy%20Policy%20-%20Employability%20Assessment%20Toolkit.pdf" target="_blank" style="text-decoration: none;"> View website Privacy Policy</strong></a></span>

                
            </a>
                               </div>
							    <div id="openid-buttons" class="d-flex gs8 gsx ai-center sm:jc-space-between" style="padding: 5px; background-color: #e1ecf4; border: 1px black solid; margin-right: 20px;">
            <a >
                    <span class="sm:d-none" ><strong > <a href="https://github.com/ITECH3208andITECH3209feduni/project-repo-project-x02/raw/master/Copyright%20Policy%20-%20Employability%20Assessment%20Toolkit.pdf" target="_blank" style="text-decoration: none;"> View website Copyright Policy</strong></a></span>

                
            </a>
             
                  </div>
		<div id="openid-buttons" class="d-flex gs8 gsx ai-center sm:jc-space-between">
          
             
                <button class="flex--item s-btn s-btn__muted s-btn__icon px8 js-dismiss" onclick="myFunction()"title="Dismiss"><svg aria-hidden="true" class="svg-icon iconClear" width="18" height="18" viewBox="0 0 18 18"><path d="M15 4.41 13.59 3 9 7.59 4.41 3 3 4.41 7.59 9 3 13.59 4.41 15 9 10.41 13.59 15 15 13.59 10.41 9 15 4.41Z"/></svg></button>
        <script>
function myFunction() {
  var x = document.getElementById("myDIV");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>
		</div>
		  <link rel="stylesheet" type="text/css" href="https://cdn.sstatic.net/Shared/stacks.css?v=b7b881f7da13">
    
    
</body>
</html>
