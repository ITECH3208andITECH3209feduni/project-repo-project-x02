// creating an array and passing the number, questions, options, and answers
let questions10 = [
    {
    numb: 1,
    question: "What score does a trainee need to get to pass the BPI Building Analyst?",
    answer: "70% Written/ 70% Field",
    options: [
      "75% Written/ 70% Field",
      "70% Written/ 70% Field",
      "75% Written / 75% Field",
    ]
  },
    {
    numb: 2,
    question: "What is the main purpose of HTML in a website?",
    answer: "70%",
    options: [
      "70%",
      "75%",
      "80%",
    ]
  },
    {
    numb: 3,
    question: "What are the Continuing Education requirements for NABCEP?",
    answer: "18 hours every 3 years",
    options: [
      "24 hours every 3 years",
      "18 hours every 3 years",
      "24 hours every 2 years",
    ]
  },
    {
    numb: 4,
    question: "Which of the following certifications do NOT qualify a business to apply for BPI Accreditation?",
    answer: "BPI Multifamily",
    options: [
      "BPI Multifamily",
      "BPI Air Sealing / Weatherization",
      "BPI Envelope Shell",
    ]
  },
    {
    numb: 5,
    question: "Which of the following is a similarity between RESNET testing and BPI testing?",
    answer: "Blower Door Test",
    options: [
      "REM/Rate Software",
      "Combustion Safety Testing",
      "Blower Door Test",
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];