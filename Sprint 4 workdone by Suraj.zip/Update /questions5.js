// creating an array and passing the number, questions, options, and answers
let questions5 = [
    {
    numb: 1,
    question: "What do julienne cuts look like?",
    answer: "Matchsticks",
    options: [
      "Coins",
      "Matchsticks",
      "Shreds",
    ]
  },
    {
    numb: 2,
    question: "What is not a binding agent in cooking?",
    answer: "Vinegar",
    options: [
      "Mayonnaise",
      "Vinegar",
      "Flour",
    ]
  },
    {
    numb: 3,
    question: "What does it mean to blanch?",
    answer: "To quickly boil and then put in ice water",
    options: [
      "To cook from Frozen",
      "To quickly boil and then put in ice water",
      "To quickly sear at avery hot temperature",
    ]
  },
    {
    numb: 4,
    question: "What are the two main ingredients in a custard?",
    answer: "Egg yolks and cream",
    options: [
      "Egg whites and whipping cream",
      "Egg yolks and cream",
      "Cream and butter",
    ]
  },
    {
    numb: 5,
    question: " Which of these has the highest smoke point?",
    answer: "Avocado oil",
    options: [
      "Extra-virgin olive oil",
      "Avocado oil",
      "Canola oil",
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];