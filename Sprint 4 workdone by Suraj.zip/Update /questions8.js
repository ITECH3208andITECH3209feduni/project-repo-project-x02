// creating an array and passing the number, questions, options, and answers
let questions8 = [
    {
    numb: 1,
    question: "Patients with schizophrenia will most likely display ____ in their brains.",
    answer: "Enlarged ventricles",
    options: [
      "Blood clots",
      "Enlarged ventricles",
      "Discoloratiom of connectives tissuesv",
    ]
  },
    {
    numb: 2,
    question: "Which type of behavior modification relies on consequences?",
    answer: "Operant conditioning",
    options: [
      "Classical conditioning",
      "Operant conditioning",
      "Aversion therapyv",
    ]
  },
    {
    numb: 3,
    question: "According to Freud, which inner force contains the libido?",
    answer: "Id",
    options: [
      "Superid",
      "Ego",
      "Id",
    ]
  },
    {
    numb: 4,
    question: "Which of these is not one of Freud’s stages of psychosexual development?",
    answer: "Curious",
    options: [
      "Phallic",
      "Curious",
      "Oral",
    ]
  },
    {
    numb: 5,
    question: "Which of these might be prescribed to a patient who has been diagnosed with major depressive disorder?",
    answer: "SSRI",
    options: [
      "SSRI",
      "Norepinephrine",
      "Acetylcholine",
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];