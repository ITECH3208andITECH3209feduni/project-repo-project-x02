// creating an array and passing the number, questions, options, and answers
let questions2 = [
    {
    numb: 1,
    question: "You should not ask people with disabilities to participate in moderate and vigorous physical activity because the intensity is too high for them.",
    answer: "False",
    options: [
      "True",
      "False",
    ]
  },
    {
    numb: 2,
    question: "Zack is a 62-year old man. His resting heart rate is 82. if he wants to participate in moderate physical activity, his target rate will be?",
    answer: "132",
    options: [
      "132",
      "148",
 
    ]
  },
    {
    numb: 3,
    question: "Older adults are most concerned about fanatical pressures for themselves.",
    answer: "False",
    options: [
      "True",
      "False",
    ]
  },
    {
    numb: 4,
    question: " Percentage of adults who achieve a least 3000 minutes a week of moderate-intensity aerobic physical activity or 150 minutes a week of vigorous-intensity aerobic activity decreases with age.",
    answer: "False",
    options: [
      "True",
      "False",
    ]
  },
    {
    numb: 5,
    question: "If you want to design the exercise for older adults who need to improve skills in moving furniture, do kitchen activities, putting things away and shopping cart, what kinds of exercise would be most suitable for the population?",
    answer: "wall push ups",
    options: [
      "wall push ups",
      "leg press",
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];