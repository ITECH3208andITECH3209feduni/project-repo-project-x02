// creating an array and passing the number, questions, options, and answers
let questions7 = [
    {
    numb: 1,
    question: "What is halitosis?",
    answer: "Bad breath",
    options: [
      "Dental filling",
      "Regular dental checkups",
      "Bad breath",
    ]
  },
    {
    numb: 2,
    question: "What is gingivitis?",
    answer: "Inflammation of the gums",
    options: [
      "Tooth erosion",
      "Inflammation of the gums",
      "Mouth sores",
    ]
  },
    {
    numb: 3,
    question: "What is this procedure to replace a missing tooth termed as?",
    answer: "Dental implant",
    options: [
      "Tooth-supported fixed bridge",
      "Removal partial denture",
      "Dental implant",
    ]
  },
    {
    numb: 4,
    question: "Which of the following procedures is considered as orthodontia?",
    answer: "Braces installation",
    options: [
      "Teeth whitening",
      "Dental bonding",
      "Braces installation",
    ]
  },
    {
    numb: 5,
    question: "Why would a patient require a root canal treatment?",
    answer: "To treat diseases and injuries to the dental pulp so as to conserve a tooth that will otherwise have to be extracted",
    options: [
      "To treat diseases and injuries to the dental pulp so as to conserve a tooth that will otherwise have to be extracted",
      "To correct the alignment of teeth and bite-related problems",
      "To repair chipped decayed or stained teeth and help in closing gaps between teeth",
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];