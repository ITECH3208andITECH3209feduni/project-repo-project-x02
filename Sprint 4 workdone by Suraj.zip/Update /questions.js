// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "This is the step of the nursing process where you do the PES.",
    answer: "Diagonsis",
    options: [
      "Planning",
      "Implementation ",
      "Diagonsis",
    ]
  },
    {
    numb: 2,
    question: "What purpose does the nursing process serve?",
    answer: "Providing nurses with a framework to aid them in delivering comprenhensive care",
    options: [
      "Assisting family members in making important healthcare decision decisions",
      "Providing nurses with a framework to aid them in delivering comprenhensive care",
      "Help other healthcare professionals know what is going on with the client",
    ]
  },
    {
    numb: 3,
    question: "which could be considered objective data from the following?",
    answer: "A temperature of 100.1 degrees fahrenheit",
    options: [
      "A temperature of 100.1 degrees fahrenheit",
      "A patient's report of moderate pain",
      "Complaints of nausea",
    ]
  },
    {
    numb: 4,
    question: "Which nusring diagnosis should recieve the highest priority in the case of a female patient who is diagnosed with deep vein thrombosis?",
    answer: "Altered peripheral tissue perfusion related tovenous congestion",
    options: [
      "Impaired gas exchange realating to an increased blood flow",
      "Fluid volume excess relating to peripheral vascular disease",
      "Altered peripheral tissue perfusion related tovenous congestion",
      
    ]
  },
    {
    numb: 5,
    question: "From the following, which independent nursing intervention can a nurse include in the plan of care for a patient with fractured tibia?",
    answer: "Elevate the leg 5 inches above the heart",
    options: [
      "Perform a range of motion to right leg every 4 hour",
      "Elevate the leg 5 inches above the heart",
      "Apply a cold pack to the tibia",
      
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];