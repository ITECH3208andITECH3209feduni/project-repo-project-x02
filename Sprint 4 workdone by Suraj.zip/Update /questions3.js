// creating an array and passing the number, questions, options, and answers
let questions3 = [
    {
    numb: 1,
    question: "What will happen if your catalytic converter is going bad?",
    answer: "Your engine will turn off or stall upon a complete stop",
    options: [
      "Your vehicle will shake upon driving.",
      "Your engine will turn off or stall upon a complete stop",
      "Your vehicle will backfire upon driving",
    ]
  },
    {
    numb: 2,
    question: "What will happen if your constant velocity or cv joint is going bad?",
    answer: "Your wheels will make a clicking sound upon turning the wheels",
    options: [
      "There will be a burning smell upon driving",
      "Your vehicle shake upon backing up",
      "Your wheels will make a clicking sound upon turning the wheels",
    ]
  },
    {
    numb: 3,
    question: "What will happen if you place the spark plug wires out of origional order?",
    answer: "Your engine will misfire upon starting",
    options: [
      "Your vehicle will backfire upon drivig",
      "Your engine will misfire upon starting",
      "Your engine will stall upon driving",
    ]
  },
    {
    numb: 4,
    question: "What will happen if you do not screw your spark plugs in tightly or correctly?",
    answer: "The plug will blow out with a pop and the engine will turn off immediately after starting",
    options: [
      "The plug will blow out with a pop and the engine will turn off immediately after starting",
      "Your vehicle will smoke soon after starting",
      "Your plug will fall out soon after driving",
    ]
  },
    {
    numb: 5,
    question: "What will happen if your wheel barrings need tightened?",
    answer: "Your vehicle will not ride smooth upon driving",
    options: [
      "Your wheels will rust and decay upon driving",
      "Your vehicle will not ride smooth upon driving",
      "Your tires will fly off of the wheels upon driving",
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];