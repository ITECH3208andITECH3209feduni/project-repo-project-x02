// creating an array and passing the number, questions, options, and answers
let questions6 = [
    {
    numb: 1,
    question: "In JavaScript, what method adds an element to the end of an array?",
    answer: ".push()",
    options: [
      ".pop()",
      ".unshift()",
      ".push()",
    ]
  },
    {
    numb: 2,
    question: "What is the main purpose of HTML in a website?",
    answer: "Structure",
    options: [
      "Style",
      "Structure",
      "Functionality",
    ]
  },
    {
    numb: 3,
    question: "In CSS, what does the A stand for in HSLA?",
    answer: "Alpha",
    options: [
      "Alpha",
      "Ancient",
      "Ambiguous",
    ]
  },
    {
    numb: 4,
    question: "In CSS, how do you add content before an element?",
    answer: "::before",
    options: [
      "::after",
      "::before",
      "::add-content",
    ]
  },
    {
    numb: 5,
    question: "In JavaScript, which of the following methods returns the milliseconds in the specified date according to local time?",
    answer: "getMilliseconds()",
    options: [
      "getMilliseconds()",
      "getMinutes()",
      "getTheMillisecondsNow()",
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];