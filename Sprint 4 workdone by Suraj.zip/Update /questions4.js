// creating an array and passing the number, questions, options, and answers
let questions4 = [
    {
    numb: 1,
    question: "The positive effects of early learning are still measurable when a child is:",
    answer: "5 years old",
    options: [
      "5 years old",
      "7 years old",
      "15 years old",
    ]
  },
    {
    numb: 2,
    question: "Who is Bluey?",
    answer: "A 1970s TV detective",
    options: [
      "An animated dog on Australian TV",
      "A 1970s TV detective",
      "A budgerigar",
    ]
  },
    {
    numb: 3,
    question: "According to research, what is the most important factor in delivering high quality early learning and care?",
    answer: "Educators who can create strong relationships with children",
    options: [
      "The amount of money spent on toys",
      "The colour of the walls",
      "Educators who can create strong relationships with children",
    ]
  },
    {
    numb: 4,
    question: "What is the difference between a childcare worker and an early childhood educator? ",
    answer: "Childcare worker and early childhood educator are the same thing",
    options: [
      "A childcare worker does administrative work, not teaching.",
      "A childcare worker is less experienced than an early childhood educator.",
      "Childcare worker and early childhood educator are the same thing",
    ]
  },
    {
    numb: 5,
    question: "I am most attracted to jobs that have:",
    answer: "The feeling that I’m making a difference in the world",
    options: [
      "A supportive team",
      "The opportunity to progress in my career",
      "The feeling that I’m making a difference in the world",
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];