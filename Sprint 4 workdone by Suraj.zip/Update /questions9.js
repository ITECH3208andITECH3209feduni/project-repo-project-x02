// creating an array and passing the number, questions, options, and answers
let questions9 = [
    {
    numb: 1,
    question: "Which tool is used in business analyst?",
    answer: "My Excel",
    options: [
      "My Sql",
      "My Excel",
      "MS Access",
    ]
  },
    {
    numb: 2,
    question: "FMEA stands for?",
    answer: "Failure Mode and Effect Anyalsis",
    options: [
      "Functions Managed Extension Activities",
      "Failure Mode and Effect Anyalsis",
      "Functions Mode and Effects Analysis",
    ]
  },
    {
    numb: 3,
    question: "_________ Analysis is used to analyze a system in terms of its requirements to identify its impact on customer satisfaction.",
    answer: "Kano",
    options: [
      "Kano",
      "Paretto",
      "Root Cause",
    ]
  },
    {
    numb: 4,
    question: "The ______ Technique is used to give priority to various items in a process",
    answer: "Pair-Choice",
    options: [
      "Pair-Choice",
      "Paretto",
      "Impact",
    ]
  },
    {
    numb: 5,
    question: "Which of the following is not one of the three major classes of information systems?",
    answer: "Collaboration system",
    options: [
      "Management information system",
      "Transaction processing system",
      "Collaboration system",
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];